export type Cargo = {
    id: number;
    descricao: string;
    local: string;
    anoInicio: string;
    anoFim: string;
};