export type Depoimento = {
    id: number;
    texto: string;
    data: string;
};