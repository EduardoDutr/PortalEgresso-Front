export type Egresso = {
    id: number;
    nome: string;
    email: string;
    descricao: string;
    instagram: string;
    linkedin: string;
    curriculo: string;
    foto: string;
};