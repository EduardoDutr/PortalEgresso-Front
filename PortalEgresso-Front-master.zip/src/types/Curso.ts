export type Curso = {
    id: number;
    nome: string;
    nivel: string;
};