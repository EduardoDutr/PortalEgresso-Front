export type Oportunidade = {
    id: string;
    titulo: string;
    descricao: string;
    link: string;
}